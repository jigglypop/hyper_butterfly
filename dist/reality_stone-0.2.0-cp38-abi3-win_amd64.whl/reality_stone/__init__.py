from ._backend import (
    mobius_add as _mobius_add,
    mobius_scalar as _mobius_scalar,
    poincare_distance as _poincare_distance,
    poincare_to_lorentz as _poincare_to_lorentz,
    poincare_to_klein as _poincare_to_klein,
    lorentz_add as _lorentz_add,
    lorentz_scalar as _lorentz_scalar,
    lorentz_distance as _lorentz_distance,
    lorentz_inner as _lorentz_inner,
    lorentz_to_poincare as _lorentz_to_poincare,
    lorentz_to_klein as _lorentz_to_klein,
    klein_add as _klein_add,
    klein_scalar as _klein_scalar,
    klein_distance as _klein_distance,
    klein_to_poincare as _klein_to_poincare,
    klein_to_lorentz as _klein_to_lorentz
)

class Mobius:
    @staticmethod
    def add(u, v, c=1.0):
        return _mobius_add(u, v, c)
    @staticmethod
    def scalar(u, r, c=1.0):
        return _mobius_scalar(u, r, c)

class Poincare:
    @staticmethod
    def add(u, v, c=1.0):
        return _mobius_add(u, v, c)
    @staticmethod
    def distance(u, v, c=1.0):
        return _poincare_distance(u, v, c)
    @staticmethod
    def to_lorentz(x, c=1.0):
        return _poincare_to_lorentz(x, c)
    @staticmethod
    def to_klein(x, c=1.0):
        return _poincare_to_klein(x, c)

class Lorentz:
    @staticmethod
    def add(u, v, c=1.0):
        return _lorentz_add(u, v, c)
    @staticmethod
    def scalar(u, r, c=1.0):
        return _lorentz_scalar(u, r, c)
    @staticmethod
    def distance(u, v, c=1.0):
        return _lorentz_distance(u, v, c)
    @staticmethod
    def inner(u, v):
        return _lorentz_inner(u, v)
    @staticmethod
    def to_poincare(x, c=1.0):
        return _lorentz_to_poincare(x, c)
    @staticmethod
    def to_klein(x, c=1.0):
        return _lorentz_to_klein(x, c)

class Klein:
    @staticmethod
    def add(u, v, c=1.0):
        return _klein_add(u, v, c)
    @staticmethod
    def scalar(u, r, c=1.0):
        return _klein_scalar(u, r, c)
    @staticmethod
    def distance(u, v, c=1.0):
        return _klein_distance(u, v, c)
    @staticmethod
    def to_poincare(x, c=1.0):
        return _klein_to_poincare(x, c)
    @staticmethod
    def to_lorentz(x, c=1.0):
        return _klein_to_lorentz(x, c)

__all__ = ['Mobius', 'Poincare', 'Lorentz', 'Klein'] 
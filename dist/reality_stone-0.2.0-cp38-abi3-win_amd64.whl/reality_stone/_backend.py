"""
Reality Stone - High-performance hyperbolic neural networks
Powered by Rust + PyTorch
"""

__version__ = "0.2.0"

import torch
from torch.autograd import Function
import numpy as np

try:
    from . import _rust
except ImportError:
    def _dummy_factory(*args, **kwargs):
        raise ImportError("Could not import the Rust backend. Please make sure the project is built correctly.")
    class _dummy_rust:
        def __getattr__(self, name):
            return _dummy_factory
    _rust = _dummy_rust()

def _to_numpy(tensor):
    if isinstance(tensor, torch.Tensor):
        return tensor.detach().cpu().numpy().astype(np.float32)
    return np.asarray(tensor, dtype=np.float32)

def _from_numpy(array, device=None, dtype=torch.float32):
    tensor = torch.from_numpy(array).to(dtype)
    if device is not None:
        tensor = tensor.to(device)
    return tensor

def mobius_add(u, v, c=1.0):
    return _from_numpy(_rust.mobius_add(_to_numpy(u), _to_numpy(v), float(c)), u.device)

def mobius_scalar(u, r, c=1.0):
    return _from_numpy(_rust.mobius_scalar(_to_numpy(u), float(r), float(c)), u.device)

def poincare_distance(u, v, c=1.0):
    return _from_numpy(_rust.poincare_distance(_to_numpy(u), _to_numpy(v), float(c)), u.device)

def poincare_to_lorentz(x, c=1.0):
    return _from_numpy(_rust.poincare_to_lorentz(_to_numpy(x), float(c)), x.device)

def poincare_to_klein(x, c=1.0):
    return _from_numpy(_rust.poincare_to_klein(_to_numpy(x), float(c)), x.device)

def lorentz_add(u, v, c=1.0):
    return _from_numpy(_rust.lorentz_add(_to_numpy(u), _to_numpy(v), float(c)), u.device)

def lorentz_scalar(u, r, c=1.0):
    return _from_numpy(_rust.lorentz_scalar(_to_numpy(u), float(r), float(c)), u.device)

def lorentz_distance(u, v, c=1.0):
    return _from_numpy(_rust.lorentz_distance(_to_numpy(u), _to_numpy(v), float(c)), u.device)

def lorentz_inner(u, v):
    return _from_numpy(_rust.lorentz_inner(_to_numpy(u), _to_numpy(v)), u.device)

def lorentz_to_poincare(x, c=1.0):
    return _from_numpy(_rust.lorentz_to_poincare(_to_numpy(x), float(c)), x.device)

def lorentz_to_klein(x, c=1.0):
    return _from_numpy(_rust.lorentz_to_klein(_to_numpy(x), float(c)), x.device)

def klein_add(u, v, c=1.0):
    return _from_numpy(_rust.klein_add(_to_numpy(u), _to_numpy(v), float(c)), u.device)

def klein_scalar(u, r, c=1.0):
    return _from_numpy(_rust.klein_scalar(_to_numpy(u), float(r), float(c)), u.device)

def klein_distance(u, v, c=1.0):
    return _from_numpy(_rust.klein_distance(_to_numpy(u), _to_numpy(v), float(c)), u.device)

def klein_to_poincare(x, c=1.0):
    return _from_numpy(_rust.klein_to_poincare(_to_numpy(x), float(c)), x.device)

def klein_to_lorentz(x, c=1.0):
    return _from_numpy(_rust.klein_to_lorentz(_to_numpy(x), float(c)), x.device)

__all__ = [
    'mobius_add', 'mobius_scalar', 'poincare_distance', 'poincare_to_lorentz', 'poincare_to_klein',
    'lorentz_add', 'lorentz_scalar', 'lorentz_distance', 'lorentz_inner', 'lorentz_to_poincare', 'lorentz_to_klein',
    'klein_add', 'klein_scalar', 'klein_distance', 'klein_to_poincare', 'klein_to_lorentz'
]